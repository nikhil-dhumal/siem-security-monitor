import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  isAuthenticated: false,
  user: null,
  token: null,
  roles: [],
  initialized: false,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setAuthState: (state, action) => {
      const { user, token, roles } = action.payload;
      console.log('setAuthState reducer called', { payloadUser: user, payloadToken: !!token, payloadRoles: roles, resultingIsAuthenticated: Boolean(token) });
      state.isAuthenticated = Boolean(token);
      state.user = user;
      state.token = token;
      state.roles = roles || [];
      state.initialized = true;
    },
    logout: (state) => {
      console.log('logout reducer called');
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      state.roles = [];
      state.initialized = true;
      localStorage.removeItem('actkn');
    },
  },
});

export const { setAuthState, logout } = authSlice.actions;
export default authSlice.reducer;
