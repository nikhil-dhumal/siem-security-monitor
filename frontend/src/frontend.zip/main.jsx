// main.jsx — call init BEFORE React renders anything
import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { store } from './app/store';
import App from './App';
import { initKeycloak, kc } from './auth/keycloak';
import { setAuthState, logout } from './features/auth/authSlice';

initKeycloak().then((authenticated) => {
  if (authenticated) {
    const profile = kc.tokenParsed || {};
    const roles = profile.realm_access?.roles || [];
    localStorage.setItem('actkn', kc.token);
    store.dispatch(setAuthState({ user: profile, token: kc.token, roles }));

    kc.onTokenExpired = () => {
      kc.updateToken(60).then((refreshed) => {
        if (refreshed) {
          localStorage.setItem('actkn', kc.token);
          store.dispatch(setAuthState({
            user: kc.tokenParsed,
            token: kc.token,
            roles: kc.tokenParsed?.realm_access?.roles || [],
          }));
        }
      }).catch(() => {
        localStorage.removeItem('actkn');
        store.dispatch(logout());
      });
    };
  } else {
    store.dispatch(logout());
  }
}).catch(() => {
  store.dispatch(logout());
}).finally(() => {
  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <Provider store={store}>
        <App />
      </Provider>
    </React.StrictMode>
  );
});