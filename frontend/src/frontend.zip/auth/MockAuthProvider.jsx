// Mock authentication provider for development
import { useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { setAuthState, logout } from '../features/auth/authSlice';

const MockAuthProvider = ({ children }) => {
  const dispatch = useDispatch();
  const initRef = useRef(false);

  console.log('MockAuthProvider component rendered');

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    console.log('MockAuthProvider init starting');

    // Simulate authentication check
    const urlParams = new URLSearchParams(window.location.search);
    const mockUser = urlParams.get('mock_user');

    if (mockUser) {
      // User just logged in via mock login
      const userData = getMockUserData(mockUser);
      dispatch(setAuthState({
        user: userData,
        token: 'mock-jwt-token-' + Date.now(),
        roles: userData.roles || []
      }));

      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } else {
      // Check if user is already logged in (from localStorage)
      const storedToken = localStorage.getItem('mock_token');
      const storedUser = localStorage.getItem('mock_user');

      if (storedToken && storedUser) {
        try {
          const userData = JSON.parse(storedUser);
          dispatch(setAuthState({
            user: userData,
            token: storedToken,
            roles: userData.roles || []
          }));
        } catch (e) {
          localStorage.removeItem('mock_token');
          localStorage.removeItem('mock_user');
          dispatch(logout());
        }
      } else {
        dispatch(logout());
      }
    }

    console.log('MockAuthProvider init complete');
  }, [dispatch]);

  return children;
};

// Mock logout function
export const mockLogout = () => {
  localStorage.removeItem('mock_token');
  localStorage.removeItem('mock_user');
  window.location.href = '/login';
};

// Mock user data
function getMockUserData(username) {
  const mockUsers = {
    'viewer': {
      sub: 'viewer-123',
      name: 'Demo Viewer',
      preferred_username: 'viewer',
      email: 'viewer@demo.com',
      realm_access: { roles: ['viewer'] },
      roles: ['viewer']
    },
    'admin': {
      sub: 'admin-456',
      name: 'Demo Admin',
      preferred_username: 'admin',
      email: 'admin@demo.com',
      realm_access: { roles: ['admin', 'viewer'] },
      roles: ['admin', 'viewer']
    },
    'simulator': {
      sub: 'simulator-789',
      name: 'Demo Simulator',
      preferred_username: 'simulator',
      email: 'simulator@demo.com',
      realm_access: { roles: ['simulator', 'viewer'] },
      roles: ['simulator', 'viewer']
    }
  };

  return mockUsers[username] || mockUsers['viewer'];
}

export default MockAuthProvider;