// keycloak.js — new file, NOT a component
import Keycloak from 'keycloak-js';
import keycloakConfig from '../config/keycloakConfig';

export const kc = new Keycloak(keycloakConfig);

let _initPromise = null;

export function initKeycloak() {
  if (_initPromise) return _initPromise; // guarantee single init ever

  _initPromise = kc.init({
    onLoad: 'check-sso',
    checkLoginIframe: false,
    pkceMethod: 'S256',
    flow: 'standard',
    responseMode: 'query',
    redirectUri: window.location.origin + '/',
  });

  return _initPromise;
}