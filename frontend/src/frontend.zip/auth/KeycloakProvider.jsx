import { useEffect, useRef } from 'react';
import Keycloak from 'keycloak-js';
import { useDispatch } from 'react-redux';
import { setAuthState, logout } from '../features/auth/authSlice';
import keycloakConfig from '../config/keycloakConfig';

const kc = new Keycloak(keycloakConfig); // singleton — never recreated
export { kc as keycloak };

const KeycloakProvider = ({ children }) => {
  const dispatch = useDispatch();
  const initRef = useRef(false);

  console.log('KeycloakProvider component rendered');

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    console.log('KeycloakProvider init starting', {
      href: window.location.href,
      search: window.location.search,
      hash: window.location.hash,
      keycloakUrl: kc.authServerUrl || keycloakConfig.url,
      keycloakRealm: kc.realm || keycloakConfig.realm,
      keycloakClientId: kc.clientId || keycloakConfig.clientId,
      keycloakConfig,
      kcInstance: kc ? 'exists' : 'null',
      kcType: typeof kc
    });

    // Check if we have auth parameters in the URL (indicating a redirect from Keycloak)
    const hasAuthCode = window.location.hash.includes('code=') || window.location.search.includes('code=');
    const hasError = window.location.search.includes('error=');

    console.log('Auth state check:', { hasAuthCode, hasError, href: window.location.href });

    const initOptions = {
      onLoad: 'check-sso',
      checkLoginIframe: false,
      pkceMethod: 'S256',
      flow: 'standard',
      responseMode: 'query',
      redirectUri: window.location.origin + '/',
    };

    console.log('Calling kc.init with options:', initOptions);

    const initResult = kc.init(initOptions);
    console.log('kc.init() returned:', initResult, 'type:', typeof initResult);

    if (initResult && typeof initResult.then === 'function') {
      console.log('kc.init() returned a promise, waiting for resolution...');

      // Add timeout to the promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Keycloak init timeout')), 10000);
      });

      Promise.race([initResult, timeoutPromise]).then((authenticated) => {
        console.log('kc.init() promise resolved successfully:', authenticated);
        console.log('KeycloakProvider init result', {
          authenticated,
          token: kc.token,
          tokenParsed: kc.tokenParsed,
          authServerUrl: kc.authServerUrl,
          realmUrl: kc.realmUrl,
          search: window.location.search,
          hash: window.location.hash
        });

        if (authenticated) {
          const profile = kc.tokenParsed || {};
          const roles = profile.realm_access?.roles || [];
          localStorage.setItem('actkn', kc.token);
          dispatch(setAuthState({ user: profile, token: kc.token, roles }));

          // Clear auth params from URL after successful login
          window.history.replaceState({}, document.title, window.location.pathname);

          // Auto-refresh token before it expires
          kc.onTokenExpired = () => {
            kc.updateToken(60).then((refreshed) => {
              if (refreshed) {
                localStorage.setItem('actkn', kc.token);
                dispatch(setAuthState({
                  user: kc.tokenParsed,
                  token: kc.token,
                  roles: kc.tokenParsed?.realm_access?.roles || [],
                }));
              }
            }).catch(() => {
              dispatch(logout());
              localStorage.removeItem('actkn');
            });
          };
        } else {
          dispatch(logout()); // sets initialized: true, isAuthenticated: false
        }
      }).catch((error) => {
        console.error('KeycloakProvider init failed!', {
          errorIsUndefined: error === undefined,
          errorIsNull: error === null,
          errorType: typeof error,
          errorString: String(error),
          errorMessage: error?.message,
          errorError: error instanceof Error,
          fullError: error,
          href: window.location.href,
          hash: window.location.hash,
        });
        // Only logout if we're NOT in a callback redirect (to avoid losing the code)
        if (!window.location.hash.includes('code=') && !window.location.search.includes('code=')) {
          dispatch(logout());
        } else {
          console.warn('Init failed but we have auth code in URL, marking initialized as true but unauthenticated');
          dispatch(logout()); // Still call logout to set initialized: true
        }
      });
    } else {
      console.error('kc.init() did not return a promise:', initResult);
      dispatch(logout());
    }
  }, [dispatch]);

  return children;
};

export default KeycloakProvider;