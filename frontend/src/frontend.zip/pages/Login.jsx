import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { keycloak } from '../auth/KeycloakProvider';

const Login = () => {
  const navigate = useNavigate();
  const { initialized, isAuthenticated } = useSelector((state) => state.auth);

  useEffect(() => {
    console.log('Login page useEffect', { initialized, isAuthenticated, href: window.location.href });
    if (initialized && isAuthenticated) {
      navigate('/');
    }
  }, [initialized, isAuthenticated, navigate]);

  const handleLogin = () => {
    const redirectUri = `${window.location.origin}/`;
    console.log('Login button clicked, calling keycloak.login', { redirectUri, keycloakReady: !!keycloak, keycloakUrl: keycloak?.authServerUrl });
    try {
      const loginPromise = keycloak.login({ redirectUri });
      console.log('keycloak.login() called successfully, loginPromise:', loginPromise);
    } catch (error) {
      console.error('keycloak.login() threw error:', error);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4 py-8 text-slate-100">
      <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900 p-8 shadow-xl">
        <h1 className="text-3xl font-semibold text-white">SIEM Security Monitor</h1>
        <p className="mt-3 text-slate-400">Sign in to access the security dashboard.</p>

        <div className="mt-8">
          <button
            onClick={handleLogin}
            className="w-full rounded-lg bg-blue-600 px-4 py-3 font-medium text-white transition hover:bg-blue-700"
          >
            Sign In with Keycloak
          </button>
        </div>

        <div className="mt-6 text-center text-sm text-slate-400">
          <p>Demo credentials:</p>
          <p>viewer/viewer • admin/admin • simulator/simulator</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
